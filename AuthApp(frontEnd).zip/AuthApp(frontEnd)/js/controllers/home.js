myApp.controller('HomeCtrl', ['$scope', function($scope) {
    $scope.message = $scope['$scope.user.email'].name +" , you made it";
}]);